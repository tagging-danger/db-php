<?php
session_start(); // Start the session

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contact";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$username = $_POST['username'];

// Retrieve admin credentials from the database
$sql = "SELECT * FROM admin WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Admin found
    $_SESSION['admin'] = true; // Set the session variable
    // Redirect to ad.php after login
    header("Location: password.php");
} else {
    // Admin not found
    echo "Admin not found!";
}

$conn->close();
?>

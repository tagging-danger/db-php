<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
     <style>
        body {
            background: linear-gradient(to right, #c31432, #240b36); /* Background gradient effect */
            color: #fff; /* Text color */
            font-family: 'Arial', sans-serif;
            text-align: center;
            padding: 50px;
            margin: 0;
        }

        h2 {
            margin-bottom: 30px;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.8); /* Form background with transparency */
            padding: 20px;
            border-radius: 10px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #f8f8f8;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Contact Us</h2>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "contact";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $name = validateInput($_POST['name'], 15);
        $email = validateInput($_POST['email'], 50);
        $message = validateInput($_POST['message'], 500);

        if ($name !== false && $email !== false && $message !== false) {
            // Hash the message for additional security
            $hashedMessage = password_hash($message, PASSWORD_DEFAULT);

            $sql = "INSERT INTO contacts (name, email, message) VALUES ('$name', '$email', '$hashedMessage')";

            if ($conn->query($sql) === TRUE) {
                echo "Form submitted successfully by $name!";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        $conn->close();
    }

    function validateInput($input, $maxLength) {
        $trimmedInput = trim($input);
        if (strlen($trimmedInput) > 0 && strlen($trimmedInput) <= $maxLength) {
            return htmlspecialchars($trimmedInput);
        } else {
            echo "Invalid input! Ensure that it is not empty and does not exceed $maxLength characters.";
            return false;
        }
    }
    ?>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <label for="name">Name (max 15 characters):</label>
        <input type="text" name="name" maxlength="15" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="message">Message (max 500 characters):</label>
        <textarea name="message" maxlength="500" required></textarea><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
